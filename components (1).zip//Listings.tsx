import { useState } from 'react';
import { Item } from '../App';
import { PackageIcon, MapPinIcon, Filter, CheckCircle } from 'lucide-react';
import { getCategoryImage } from '../utils/categoryImages';

type ListingsProps = {
  items: Item[];
  onViewItem: (item: Item) => void;
};

const categories = ['All', 'Wallet', 'Phone', 'Keys', 'Bag', 'Jewelry', 'Electronics', 'Documents', 'Pet', 'Clothing', 'Other'];

export function Listings({ items, onViewItem }: ListingsProps) {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedType, setSelectedType] = useState<'all' | 'lost' | 'found'>('all');
  const [showResolved, setShowResolved] = useState(false);

  const filteredItems = items.filter(item => {
    const categoryMatch = selectedCategory === 'All' || item.category === selectedCategory;
    const typeMatch = selectedType === 'all' || item.type === selectedType;
    const statusMatch = showResolved || item.status !== 'resolved';
    return categoryMatch && typeMatch && statusMatch;
  }).reverse();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-4xl bg-gradient-to-r from-purple-600 via-blue-600 to-pink-600 bg-clip-text text-transparent mb-8">Browse Items</h1>

      {/* Filters */}
      <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-lg border border-purple-200/50 p-6 mb-8">
        <div className="flex items-center gap-2 mb-4">
          <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-blue-500 rounded-lg flex items-center justify-center">
            <Filter className="w-5 h-5 text-white" />
          </div>
          <span className="bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">Filters</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm text-gray-700 mb-2">
              Item Type
            </label>
            <div className="flex gap-2 flex-wrap">
              <button
                onClick={() => setSelectedType('all')}
                className={`px-4 py-2 rounded-xl transition-all shadow-md ${
                  selectedType === 'all' 
                    ? 'bg-gradient-to-r from-purple-600 to-blue-600 text-white shadow-lg' 
                    : 'bg-white text-gray-700 hover:bg-gray-50'
                }`}
              >
                All
              </button>
              <button
                onClick={() => setSelectedType('lost')}
                className={`px-4 py-2 rounded-xl transition-all shadow-md ${
                  selectedType === 'lost' 
                    ? 'bg-gradient-to-r from-red-500 to-orange-500 text-white shadow-lg' 
                    : 'bg-white text-gray-700 hover:bg-gray-50'
                }`}
              >
                Lost
              </button>
              <button
                onClick={() => setSelectedType('found')}
                className={`px-4 py-2 rounded-xl transition-all shadow-md ${
                  selectedType === 'found' 
                    ? 'bg-gradient-to-r from-green-500 to-emerald-500 text-white shadow-lg' 
                    : 'bg-white text-gray-700 hover:bg-gray-50'
                }`}
              >
                Found
              </button>
            </div>
            
            <div className="mt-3">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={showResolved}
                  onChange={(e) => setShowResolved(e.target.checked)}
                  className="w-4 h-4 rounded border-gray-300 text-purple-600 focus:ring-purple-500"
                />
                <span className="text-sm text-gray-600">Show resolved items</span>
              </label>
            </div>
          </div>

          <div>
            <label className="block text-sm text-gray-700 mb-2">
              Category
            </label>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full px-4 py-2 bg-white border border-purple-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent shadow-md"
            >
              {categories.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Results */}
      <div className="mb-4">
        <p className="text-gray-600">
          Showing <span className="text-purple-600">{filteredItems.length}</span> {filteredItems.length === 1 ? 'item' : 'items'}
        </p>
      </div>

      {filteredItems.length === 0 ? (
        <div className="text-center py-12 bg-white/80 backdrop-blur-sm rounded-2xl border border-purple-200/50 shadow-lg">
          <PackageIcon className="w-16 h-16 text-purple-300 mx-auto mb-4" />
          <p className="text-gray-500">No items found matching your filters</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map(item => (
            <button
              key={item.id}
              onClick={() => onViewItem(item)}
              className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-lg border border-gray-200/50 overflow-hidden hover:shadow-2xl transition-all text-left transform hover:scale-105"
            >
              <div className="aspect-video bg-gradient-to-br from-purple-100 to-blue-100 flex items-center justify-center overflow-hidden">
                <img 
                  src={item.imageURL || getCategoryImage(item.category)} 
                  alt={item.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <span className={`px-2 py-1 rounded-lg text-xs text-white shadow-md ${
                    item.type === 'lost' 
                      ? 'bg-gradient-to-r from-red-500 to-orange-500' 
                      : 'bg-gradient-to-r from-green-500 to-emerald-500'
                  }`}>
                    {item.type === 'lost' ? 'Lost' : 'Found'}
                  </span>
                  <span className="px-2 py-1 bg-gradient-to-r from-purple-100 to-blue-100 text-purple-700 rounded-lg text-xs">
                    {item.category}
                  </span>
                  {item.status === 'resolved' && (
                    <span className="px-2 py-1 bg-gradient-to-r from-green-100 to-emerald-100 text-green-700 rounded-lg text-xs flex items-center gap-1">
                      <CheckCircle className="w-3 h-3" />
                      Resolved
                    </span>
                  )}
                </div>
                <h3 className="text-gray-900 mb-2">{item.title}</h3>
                <p className="text-sm text-gray-600 mb-2 line-clamp-2">{item.description}</p>
                <div className="flex items-center gap-1 text-sm text-gray-500 mb-1">
                  <MapPinIcon className="w-4 h-4 text-purple-500" />
                  {item.location}
                </div>
                <p className="text-sm text-gray-500">
                  {new Date(item.date).toLocaleDateString()}
                </p>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}