import { useState } from 'react';
import { Item } from '../App';
import { PackageIcon, MapPinIcon, Edit2, Trash2, CalendarIcon, CheckCircle } from 'lucide-react';
import { EditItemModal } from './EditItemModal';
import { getCategoryImage } from '../utils/categoryImages';

type DashboardProps = {
  items: Item[];
  onViewItem: (item: Item) => void;
  onUpdateItem: (id: string, updates: Partial<Item>) => void;
  onDeleteItem: (id: string) => void;
};

export function Dashboard({ items, onViewItem, onUpdateItem, onDeleteItem }: DashboardProps) {
  const [editingItem, setEditingItem] = useState<Item | null>(null);

  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to delete this item?')) {
      onDeleteItem(id);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-4xl bg-gradient-to-r from-teal-600 via-emerald-600 to-green-600 bg-clip-text text-transparent mb-8">My Dashboard</h1>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white p-6 rounded-2xl shadow-md border border-gray-100 transform hover:scale-105 transition-transform">
          <div className="text-3xl bg-gradient-to-r from-teal-600 to-emerald-600 bg-clip-text text-transparent mb-2">
            {items.length}
          </div>
          <div className="text-gray-600">Total Reports</div>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-md border border-gray-100 transform hover:scale-105 transition-transform">
          <div className="text-3xl bg-gradient-to-r from-red-500 to-orange-500 bg-clip-text text-transparent mb-2">
            {items.filter(i => i.type === 'lost').length}
          </div>
          <div className="text-gray-600">Lost Items</div>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-md border border-gray-100 transform hover:scale-105 transition-transform">
          <div className="text-3xl bg-gradient-to-r from-green-500 to-emerald-500 bg-clip-text text-transparent mb-2">
            {items.filter(i => i.type === 'found').length}
          </div>
          <div className="text-gray-600">Found Items</div>
        </div>
      </div>

      {/* Items List */}
      <div className="mb-6">
        <h2 className="text-2xl text-gray-800 mb-2">My Reports</h2>
        <p className="text-gray-500">Manage all your reported items</p>
      </div>

      {items.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-2xl border border-gray-100 shadow-md">
          <PackageIcon className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500">You haven't reported any items yet</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {items.reverse().map(item => (
            <div key={item.id} className="bg-white rounded-2xl shadow-md border border-gray-100 overflow-hidden hover:shadow-xl transition-all">
              {/* Status Badge */}
              <div className="relative">
                <div className="absolute top-3 left-3 z-10 flex flex-col gap-2">
                  <span className={`px-3 py-1 rounded-full text-xs text-white shadow-lg ${
                    item.type === 'lost' 
                      ? 'bg-gradient-to-r from-red-500 to-orange-500' 
                      : 'bg-gradient-to-r from-teal-500 to-emerald-500'
                  }`}>
                    {item.type === 'lost' ? '📍 Lost' : '✓ Found'}
                  </span>
                  {item.status === 'resolved' && (
                    <span className="px-3 py-1 rounded-full text-xs bg-gradient-to-r from-green-500 to-emerald-500 text-white shadow-lg flex items-center gap-1">
                      <CheckCircle className="w-3 h-3" />
                      Claimed
                    </span>
                  )}
                </div>
                
                {/* Image */}
                <div 
                  onClick={() => onViewItem(item)}
                  className="aspect-video bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center overflow-hidden cursor-pointer"
                >
                  <img 
                    src={item.imageURL || getCategoryImage(item.category)} 
                    alt={item.title}
                    className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
                  />
                </div>
              </div>

              {/* Content */}
              <div className="p-5">
                {/* Title and Category */}
                <div className="mb-3">
                  <h3 
                    onClick={() => onViewItem(item)}
                    className="text-gray-900 mb-2 cursor-pointer hover:text-teal-600 transition-colors"
                  >
                    {item.title}
                  </h3>
                  <span className="inline-block px-2 py-1 bg-gray-100 text-gray-600 rounded-md text-xs">
                    {item.category}
                  </span>
                </div>

                {/* Description */}
                <p className="text-sm text-gray-500 mb-3 line-clamp-2">{item.description}</p>

                {/* Location */}
                <div className="flex items-center gap-1 text-sm text-gray-600 mb-2">
                  <MapPinIcon className="w-4 h-4 text-teal-600" />
                  {item.location}
                </div>

                {/* Date */}
                <div className="flex items-center gap-1 text-sm text-gray-500 mb-4">
                  <CalendarIcon className="w-4 h-4" />
                  {new Date(item.date).toLocaleDateString()}
                </div>

                {/* Actions */}
                <div className="flex gap-2">
                  <button
                    onClick={() => setEditingItem(item)}
                    className="flex-1 px-4 py-2 bg-gradient-to-r from-teal-500 to-emerald-500 text-white rounded-lg hover:from-teal-600 hover:to-emerald-600 shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 text-sm"
                  >
                    <Edit2 className="w-4 h-4" />
                    Edit
                  </button>
                  <button
                    onClick={() => handleDelete(item.id)}
                    className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 shadow-md hover:shadow-lg transition-all flex items-center justify-center"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Edit Modal */}
      {editingItem && (
        <EditItemModal
          item={editingItem}
          onSave={(updates) => {
            onUpdateItem(editingItem.id, updates);
            setEditingItem(null);
          }}
          onClose={() => setEditingItem(null)}
        />
      )}
    </div>
  );
}