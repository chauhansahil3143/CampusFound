import { Item } from '../App';
import { SearchIcon, PackageIcon, MapPinIcon, CalendarIcon } from 'lucide-react';
import { getCategoryImage } from '../utils/categoryImages';

type HomeProps = {
  items: Item[];
  onReportLost: () => void;
  onReportFound: () => void;
  onViewItem: (item: Item) => void;
};

export function Home({ items, onReportLost, onReportFound, onViewItem }: HomeProps) {
  const recentItems = items.filter(item => item.status !== 'resolved').slice(-6).reverse();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Hero Section */}
      <div className="text-center mb-16">
        <div className="inline-block mb-4 px-4 py-2 bg-gradient-to-r from-purple-100 to-blue-100 rounded-full">
          <span className="text-sm bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">Reuniting Items with Their Owners</span>
        </div>
        <h1 className="text-5xl bg-gradient-to-r from-purple-600 via-blue-600 to-pink-600 bg-clip-text text-transparent mb-4">
          Lost Something? Found Something?
        </h1>
        <p className="text-xl text-gray-600 mb-8">
          Help reunite lost items with their owners in your community
        </p>
        
        <div className="flex justify-center gap-4 flex-wrap">
          <button 
            onClick={onReportLost}
            className="px-8 py-4 bg-gradient-to-r from-red-500 to-orange-500 text-white rounded-xl hover:from-red-600 hover:to-orange-600 shadow-lg hover:shadow-xl transition-all flex items-center gap-2 transform hover:scale-105"
          >
            <SearchIcon className="w-5 h-5" />
            Report Lost Item
          </button>
          <button 
            onClick={onReportFound}
            className="px-8 py-4 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-xl hover:from-green-600 hover:to-emerald-600 shadow-lg hover:shadow-xl transition-all flex items-center gap-2 transform hover:scale-105"
          >
            <PackageIcon className="w-5 h-5" />
            Report Found Item
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
        <div className="bg-white/80 backdrop-blur-sm p-6 rounded-2xl shadow-lg border border-purple-200/50 text-center transform hover:scale-105 transition-transform">
          <div className="text-4xl bg-gradient-to-r from-red-500 to-orange-500 bg-clip-text text-transparent mb-2">
            {items.filter(i => i.type === 'lost' && i.status !== 'resolved').length}
          </div>
          <div className="text-gray-600">Active Lost Items</div>
        </div>
        <div className="bg-white/80 backdrop-blur-sm p-6 rounded-2xl shadow-lg border border-green-200/50 text-center transform hover:scale-105 transition-transform">
          <div className="text-4xl bg-gradient-to-r from-green-500 to-emerald-500 bg-clip-text text-transparent mb-2">
            {items.filter(i => i.type === 'found' && i.status !== 'resolved').length}
          </div>
          <div className="text-gray-600">Active Found Items</div>
        </div>
        <div className="bg-white/80 backdrop-blur-sm p-6 rounded-2xl shadow-lg border border-blue-200/50 text-center transform hover:scale-105 transition-transform">
          <div className="text-4xl bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent mb-2">
            {items.filter(i => i.status === 'resolved').length}
          </div>
          <div className="text-gray-600">Resolved Items</div>
        </div>
      </div>

      {/* Recent Listings */}
      <div>
        <h2 className="text-3xl bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent mb-6">Recent Reports</h2>
        
        {recentItems.length === 0 ? (
          <div className="text-center py-12 bg-white/80 backdrop-blur-sm rounded-2xl border border-purple-200/50 shadow-lg">
            <p className="text-gray-500">No items reported yet. Be the first to help!</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {recentItems.map(item => (
              <div
                key={item.id}
                className="bg-white rounded-2xl shadow-md border border-gray-100 overflow-hidden hover:shadow-xl transition-all"
              >
                {/* Status Badge */}
                <div className="relative">
                  <div className="absolute top-3 left-3 z-10">
                    <span className={`px-3 py-1 rounded-full text-xs text-white shadow-lg ${
                      item.type === 'lost' 
                        ? 'bg-gradient-to-r from-red-500 to-orange-500' 
                        : 'bg-gradient-to-r from-teal-500 to-emerald-500'
                    }`}>
                      {item.type === 'lost' ? '📍 Lost' : '✓ Found'}
                    </span>
                  </div>
                  
                  {/* Image */}
                  <button
                    onClick={() => onViewItem(item)}
                    className="w-full aspect-video bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center overflow-hidden"
                  >
                    <img 
                      src={item.imageURL || getCategoryImage(item.category)} 
                      alt={item.title}
                      className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
                    />
                  </button>
                </div>

                {/* Content */}
                <div className="p-5">
                  {/* Title and Category */}
                  <div className="mb-3">
                    <h3 
                      onClick={() => onViewItem(item)}
                      className="text-gray-900 mb-2 cursor-pointer hover:text-teal-600 transition-colors"
                    >
                      {item.title}
                    </h3>
                    <span className="inline-block px-2 py-1 bg-gray-100 text-gray-600 rounded-md text-xs">
                      {item.category}
                    </span>
                  </div>

                  {/* Description */}
                  <p className="text-sm text-gray-500 mb-3 line-clamp-2">
                    {item.description}
                  </p>

                  {/* Location */}
                  <div className="flex items-center gap-1 text-sm text-gray-600 mb-2">
                    <MapPinIcon className="w-4 h-4 text-teal-600" />
                    {item.location}
                  </div>

                  {/* Date */}
                  <div className="flex items-center gap-1 text-sm text-gray-500 mb-4">
                    <CalendarIcon className="w-4 h-4" />
                    {new Date(item.date).toLocaleDateString()}
                  </div>

                  {/* Contact Button */}
                  <button
                    onClick={() => onViewItem(item)}
                    className="w-full px-4 py-2.5 bg-gradient-to-r from-teal-500 to-emerald-500 text-white rounded-lg hover:from-teal-600 hover:to-emerald-600 shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                    </svg>
                    Contact Owner
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}