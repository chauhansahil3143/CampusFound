import { Item, User } from '../App';
import { ArrowLeft, MapPinIcon, CalendarIcon, TagIcon, MailIcon, PackageIcon, PhoneIcon, CheckCircle } from 'lucide-react';
import { getCategoryImage } from '../utils/categoryImages';

type ItemDetailsProps = {
  item: Item;
  currentUser: User | null;
  onBack: () => void;
  onEdit: () => void;
  onMarkAsFound?: (itemId: string) => void;
};

export function ItemDetails({ item, currentUser, onBack, onEdit, onMarkAsFound }: ItemDetailsProps) {
  const isOwner = currentUser?.id === item.userId;

  const handleContact = () => {
    if (item.userEmail) {
      window.location.href = `mailto:${item.userEmail}?subject=Regarding ${item.type} item: ${item.title}`;
    }
  };

  const handleCall = () => {
    if (item.userPhone) {
      window.location.href = `tel:${item.userPhone}`;
    }
  };

  const handleMarkFound = () => {
    if (onMarkAsFound && window.confirm('Mark this item as found/resolved? This will help others know it has been reunited with its owner.')) {
      onMarkAsFound(item.id);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-gray-600 hover:text-purple-600 mb-6 transition-colors"
      >
        <ArrowLeft className="w-5 h-5" />
        Back to listings
      </button>

      <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-2xl border border-purple-200/50 overflow-hidden">
        {/* Image */}
        <div className="aspect-video bg-gradient-to-br from-purple-100 via-blue-100 to-pink-100 flex items-center justify-center overflow-hidden">
          <img 
            src={item.imageURL || getCategoryImage(item.category)} 
            alt={item.title}
            className="w-full h-full object-cover"
          />
        </div>

        {/* Content */}
        <div className="p-8">
          <div className="flex items-start justify-between mb-6">
            <div>
              <div className="flex items-center gap-3 mb-3">
                <span className={`px-3 py-1 rounded-xl text-white shadow-lg ${
                  item.type === 'lost' 
                    ? 'bg-gradient-to-r from-red-500 to-orange-500' 
                    : 'bg-gradient-to-r from-green-500 to-emerald-500'
                }`}>
                  {item.type === 'lost' ? 'Lost Item' : 'Found Item'}
                </span>
                <span className="px-3 py-1 bg-gradient-to-r from-purple-100 to-blue-100 text-purple-700 rounded-xl shadow-md">
                  {item.category}
                </span>
                {item.status === 'resolved' && (
                  <span className="px-3 py-1 bg-gradient-to-r from-green-100 to-emerald-100 text-green-700 rounded-xl shadow-md flex items-center gap-1">
                    <CheckCircle className="w-4 h-4" />
                    Resolved
                  </span>
                )}
              </div>
              <h1 className="text-4xl bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent mb-2">{item.title}</h1>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div className="flex items-center gap-3 p-4 bg-gradient-to-r from-purple-50 to-blue-50 rounded-xl border border-purple-200/50">
              <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-blue-500 rounded-lg flex items-center justify-center shadow-md">
                <MapPinIcon className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="text-sm text-purple-600">Location</div>
                <div className="text-gray-900">{item.location}</div>
              </div>
            </div>

            <div className="flex items-center gap-3 p-4 bg-gradient-to-r from-blue-50 to-pink-50 rounded-xl border border-blue-200/50">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-pink-500 rounded-lg flex items-center justify-center shadow-md">
                <CalendarIcon className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="text-sm text-blue-600">
                  Date {item.type === 'lost' ? 'Lost' : 'Found'}
                </div>
                <div className="text-gray-900">{new Date(item.date).toLocaleDateString()}</div>
              </div>
            </div>

            <div className="flex items-center gap-3 p-4 bg-gradient-to-r from-pink-50 to-purple-50 rounded-xl border border-pink-200/50">
              <div className="w-10 h-10 bg-gradient-to-br from-pink-500 to-purple-500 rounded-lg flex items-center justify-center shadow-md">
                <TagIcon className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="text-sm text-pink-600">Category</div>
                <div className="text-gray-900">{item.category}</div>
              </div>
            </div>

            <div className="flex items-center gap-3 p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl border border-purple-200/50">
              <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center shadow-md">
                <CalendarIcon className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="text-sm text-purple-600">Reported On</div>
                <div className="text-gray-900">{new Date(item.createdAt).toLocaleDateString()}</div>
              </div>
            </div>
          </div>

          <div className="mb-8 p-6 bg-gradient-to-r from-purple-50 to-blue-50 rounded-xl border border-purple-200/50">
            <h2 className="text-2xl bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent mb-3">Description</h2>
            <p className="text-gray-700 whitespace-pre-wrap">{item.description}</p>
          </div>

          {/* Actions */}
          <div className="flex gap-4">
            {isOwner ? (
              <>
                <button
                  onClick={onEdit}
                  className="flex-1 px-6 py-3 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-xl hover:from-purple-700 hover:to-blue-700 shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2 transform hover:scale-105"
                >
                  Manage in Dashboard
                </button>
                {item.type === 'lost' && item.status !== 'resolved' && (
                  <button
                    onClick={handleMarkFound}
                    className="flex-1 px-6 py-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-xl hover:from-green-600 hover:to-emerald-600 shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2 transform hover:scale-105"
                  >
                    <CheckCircle className="w-5 h-5" />
                    Mark as Found
                  </button>
                )}
              </>
            ) : (
              <>
                {item.userEmail && (
                  <button
                    onClick={handleContact}
                    className="flex-1 px-6 py-3 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-xl hover:from-purple-700 hover:to-blue-700 shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2 transform hover:scale-105"
                  >
                    <MailIcon className="w-5 h-5" />
                    Email Owner
                  </button>
                )}
                {item.userPhone && (
                  <button
                    onClick={handleCall}
                    className="flex-1 px-6 py-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-xl hover:from-green-600 hover:to-emerald-600 shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2 transform hover:scale-105"
                  >
                    <PhoneIcon className="w-5 h-5" />
                    Call Owner
                  </button>
                )}
              </>
            )}
          </div>

          {!isOwner && (item.userEmail || item.userPhone) && (
            <div className="mt-4 p-4 bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-300 rounded-xl shadow-md">
              <p className="text-sm text-blue-900">
                <strong>Contact Information:</strong>
              </p>
              {item.userEmail && (
                <p className="text-sm text-blue-800 mt-1">
                  📧 {item.userEmail}
                </p>
              )}
              {item.userPhone && (
                <p className="text-sm text-blue-800 mt-1">
                  📱 {item.userPhone}
                </p>
              )}
            </div>
          )}

          {item.status === 'resolved' && (
            <div className="mt-4 p-4 bg-gradient-to-r from-green-50 to-emerald-50 border border-green-300 rounded-xl shadow-md">
              <p className="text-sm text-green-900 flex items-center gap-2">
                <CheckCircle className="w-5 h-5" />
                <strong>This item has been marked as found/resolved!</strong>
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}